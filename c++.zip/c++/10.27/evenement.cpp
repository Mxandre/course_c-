#include "evenement.h"

ostream& operator<<(ostream& f, const TIME::Evt& e) {
	e.afficher(f);
	return f;
}

TIME::Date getDateDebut(const TIME::Evt& e) {
	// si c'est un objet Evt1j, Evt1jDur ou Rdv, il faut faire getDate()
	// si c'est un objet EvtPj, il faut faire getDebut()
	// on utilise le dynamic_cast pour savoir
	using namespace TIME;
	const Evt1j* pt = dynamic_cast<const Evt1j*>(&e);
	if (pt != nullptr) // c'est un Evt1j, un Evt1jDur ou un Rdv
		return pt->getDate();
	const EvtPj* pt2 = dynamic_cast<const EvtPj*>(&e);
	if (pt2 != nullptr) // c'est un EvtPj
		return pt2->getDebut();
	// si on arrive ici, c'est que c'est un type d'�v�nement inconnu
	throw "type d'evenement inconnu";
}

bool operator<(const TIME::Evt& e1, const TIME::Evt& e2) {
	using namespace TIME;
	Date d1 = getDateDebut(e1);
	Date d2 = getDateDebut(e2);
	if (d1 < d2) return true;
	if (d2 < d1) return false;
	// si on arrive ici alors d1==d2, 
	// il faut peut �tre comparer les horaires si e1 et e2 ont des horaires
	// on peut savoir si e1 et e2 ont des horaires en essayant de convertir
	// leur adresse en Evt1jDur*
	const Evt1jDur* pt1 = dynamic_cast<const Evt1jDur*>(&e1);
	const Evt1jDur* pt2 = dynamic_cast<const Evt1jDur*>(&e2);
	if (pt1 != nullptr && pt2 == nullptr) return false;
	if (pt1 == nullptr && pt2 != nullptr) return true;
	if (pt1 == nullptr && pt2 == nullptr) return false;
	// e1 et e2 ont un horaire
	return pt1->getHoraire() < pt2->getHoraire();
}