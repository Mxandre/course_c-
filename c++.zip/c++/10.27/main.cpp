#include "graph.h"
#include <iostream>
#include <typeinfo>
#include <sstream>
#include "evenement.h"
#include "log.h"
using namespace std;
using namespace TIME;

void ex_32() {
	Evt1j e1(Date(4, 10, 1957), "Spoutnik");
	Evt1j e2(Date(11, 6, 2013), "Shenzhou");
	Evt1jDur e3(Date(11, 6, 2013), "Lancement de Longue Marche", Horaire(17, 38), Duree(0, 10));
	Rdv e4(Date(11, 4, 2013), "reunion UV", Horaire(17, 30), Duree(60), "Intervenants UV", "bureau");
	// on peut faire une conversion implicite d'un pointeur ou d'une r�f�rence 
	// d'une classe d�riv�e vers un pointeur ou une r�f�rence de la classe de base
	Evt1j * pt1 = &e1; Evt1j * pt2 = &e2; Evt1j * pt3 = &e3; Evt1j * pt4 = &e4;
	Evt1j & ref1 = e1; Evt1j & ref2 = e2; Evt1j & ref3 = e3; Evt1j & ref4 = e4;
	// mais on ne peut pas faire l'inverse :
	// Rdv* pt = pt1; => ERREUR
	// on peut convertir explicitement un pointeur d'une classe de base 
	// en pointeur de la classe d�riv�e en utilisant un dynamic_cast
	// si la conversion n'est pas possible, l'op�rateur de conversion renvoie nullptr
	Rdv* pt = dynamic_cast<Rdv*>(pt1); if(pt!=nullptr) pt->afficher(cout); // nullptr
	pt = dynamic_cast<Rdv*>(pt2); if (pt != nullptr) pt->afficher(cout); // nullptr
	pt = dynamic_cast<Rdv*>(pt3); if (pt != nullptr) pt->afficher(cout); // nullptr
	pt = dynamic_cast<Rdv*>(pt4); if (pt != nullptr) pt->afficher(cout); // il n'y a que cet affichage

	try { Rdv& r1 = dynamic_cast<Rdv&>(ref1); r1.afficher(cout); } catch (...) { /* rien */ }
	try { Rdv& r2 = dynamic_cast<Rdv&>(ref2); r2.afficher(cout); } catch (...) { /* rien */ }
	try { Rdv& r3 = dynamic_cast<Rdv&>(ref3); r3.afficher(cout); } catch (...) { /* rien */ }
	try { Rdv& r4 = dynamic_cast<Rdv&>(ref4); r4.afficher(cout); } catch (...) { /* rien */ }

}


int main() {
	MyLog ml;
	try {
		ml.addEvt(Date(27, 10, 2023), Horaire(8, 00), "d�but du TD");
		ml.addEvt(Date(27, 10, 2023), Horaire(8, 45), "d�but pause");
		ml.addEvt(Date(27, 10, 2023), Horaire(8, 55), "fin pause");
	}
	/*catch (LogException& e) {
		cout << e.what();
	}*/
	catch (std::exception& e) { // attrappe aussi les LogException
		cout << e.what();
	}


	int x=3;
	int* pt = &x;
	int& ref = *pt;

	stringstream st;
	st << "mon entier x=" << x << " et son adresse est " << pt;
	// on a fabriqu� une chaine de caract�res de la mani�re que l'on
	// �crit sur cout
	string chaine = st.str(); // str() renvoie la chaine cr��e



	Evt1j e1(Date(4, 10, 1957), "Spoutnik");
	Evt1j e2(Date(11, 6, 2013), "Shenzhou");
	Evt1jDur e3(Date(11, 6, 2013), "Lancement de Longue Marche", Horaire(17, 38), Duree(0, 10));
	Rdv e4(Date(11, 4, 2013), "reunion UV", Horaire(17, 30), Duree(60), "Intervenants UV", "		bureau");
	
	// si on compare deux �v�nements, il faut comparer les dates
	// si on compare deux �v�nements Evt1jDur ou Rdv, si les dates sont �gales, 
	// il faut aussi comparer les Horaires
	if (e1 < e2) cout << "e1 commence avant e2";
	if (e1 < e4) cout << "e1 commence avant e4";
	if (e4 < e3) cout << "e4 commence avant e3";
	
	Agenda A;
	A << e2;
	A << e1 << e3 << e4;
	A.afficher();

	cout << "=====================\n";
	for (auto it = A.begin(); it != A.end(); ++it)
		cout << *it;
	cout << "=====================\n";
	for (auto& e : A)
		cout << e;

	return 0;
}
