#if !defined(_EVENEMENT_H)
#define _EVENEMENT_H

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include "timing.h"
using namespace std;

namespace TIME {

	class Evt { // classe abstraite
	public:
		const string& getDescription() const { return sujet; }
		Evt(const string& s):sujet(s){}
		virtual ~Evt() = default; // destructeur virtual pour respecter le principe de substitution
		virtual string toString() const = 0;
		void afficher(ostream& f) const { // template method
			// impl�mentation en utilisant to_string (hook method)
			f << "***** Evt ********" << "\n";
			f << toString(); //(hook method)
			f << "******************" << "\n";
		}
	private:
		std::string sujet; // point commun de toutes les classes filles
	};

	class EvtPj : public Evt {
	public:
		EvtPj(const Date& d, const Date& f, const std::string& s):
			Evt(s),debut(d),fin(f){}
		const Date& getDebut() const { return debut; }
		const Date& getFin() const { return fin; }
		string toString() const { // hook utilis� dans Evt::afficher()
			stringstream f;
			f 	<< "Sujet=" << getDescription() << "\n"
				<< "Debut=" << debut << " fin=" << fin << "\n";
			return f.str();
		}
		/*void afficher(ostream& f) const {
			f << "***** Evt ********" << "\n"
			  << " sujet=" << getDescription() << "\n"
			  << "Debut=" << debut << " fin=" << fin << "\n";
		}*/
	private:
		Date debut;
		Date fin;
	};

	class Evt1j : public Evt {
	private:
		Date date;
		
	public:
		
		Evt1j(const Date& d, const std::string& s):
			Evt(s),date(d) { // maintenant, on appelle le constructeur de Evt
			//std::cout << "construction Evt1j " << this << "\n";
		}
		// le destructeur est polymorphique
		virtual ~Evt1j() {
			//std::cout << "destruction Evt1j " << this << "\n";
		}
		//Evt1j(const Evt1j&) = default;
		const Date& getDate() const { return date; }
		// afficher est polymorphique
		string toString() const { // hook utilis� dans Evt::afficher()
			stringstream f;
			f << "Sujet=" << getDescription() << "\n"
				<< "Debut=" << date << "\n";
			return f.str();
		}
		/*void afficher(ostream& f) const {
			f << "***** Evt ********" << "\n" 
			  << "Date=" << date << " sujet=" << getDescription() << "\n";
		}*/
	};

	class Evt1jDur : public Evt1j {
	private:
		Horaire horaire;
		Duree duree;
	public:
		
		Evt1jDur(const Date& d, const std::string& s,
			const Horaire& h, const Duree& dur) :
			Evt1j(d, s), // appel au constructeur de la classe de base
			horaire(h), duree(dur) {
			//std::cout << "construction Evt1jDur " << this << "\n";
		}
		~Evt1jDur() {
			//std::cout << "destruction Evt1jDur " << this << "\n";
		}
		const Horaire& getHoraire() const { return horaire; }
		const Duree& getDuree() const { return duree; }
		string toString() const { // hook utilis� dans Evt::afficher()
			stringstream f;
			f << Evt1j::toString()
			  << "Horaire=" << horaire << ", Duree=" << duree << "\n";
			return f.str();
		}
		/*void afficher(ostream& f) const {

			Evt1j::afficher(f);; // r�utilisation du comportement
								  // dans la classe de base
			f << "Horaire=" << horaire << ", Duree=" << duree << "\n";
		}*/
	};

	class Rdv : public Evt1jDur {
	private:
		std::string personnes;
		std::string lieu;
	public:

		Rdv(const Date& d, const std::string& s,
			const Horaire& h, const Duree& dur,
			const std::string& p, const std::string& l) :
			Evt1jDur(d, s, h, dur), personnes(p), lieu(l) {
			//std::cout << "construction Rdv " << this << "\n";
		}
		~Rdv() {
			//std::cout << "destruction Rdv " << this << "\n";
		}
		const std::string& getPersonnes() const { return personnes; }
		const std::string& getLieu() const { return lieu; }
		string toString() const { // hook utilis� dans Evt::afficher()
			stringstream f;
			f << Evt1jDur::toString()
			  << "Personnes=" << personnes << ", Lieu=" << lieu << "\n";
			return f.str();
		}
		/*void afficher(ostream& f) const {
			Evt1jDur::afficher(f); // r�utilisation du comportement
								  // dans la classe de base
			f << "Personnes=" << personnes << ", Lieu=" << lieu << "\n";
		}*/
	};



	// Interface � adapter :
	// Le comportement convient pour faire un objet Log, mais l'interface n'est pas celle que l'on souhaite
	class Agenda {
	public:
		class const_iterator {
		private :
			vector<Evt*>::const_iterator courant; // pointer sur l'evt courant
		public:
			const_iterator(vector<Evt*>::const_iterator it):courant(it){}
			const_iterator& operator++() { ++courant; return *this; }
			const_iterator& operator--() { --courant; return *this; }
			bool operator!=(const_iterator it) const { return courant != it.courant; }
			const Evt& operator*() { return **courant; // *courant renvoie un "const Evt*"
									// il faut une 2e * pour obtenir un "const Evt&"
								   }
		};
		const_iterator begin() const { return const_iterator(evts.begin()); }
		const_iterator end() const { return const_iterator(evts.end()); }
		
		Agenda() = default;
		virtual ~Agenda() = default;
		Agenda& operator<<(Evt& e) { 
			evts.push_back(&e); 
			return *this; 
		}
		
		void afficher(ostream& f = cout) const {
			f << "-- Agenda --\n";
			for (auto e : evts) e->afficher(f);
		}
		Agenda(const Agenda&) = delete;
		Agenda& operator=(const Agenda&) = delete;
	private:
		vector<Evt*> evts;
	};
}

ostream& operator<<(ostream&, const TIME::Evt& e);

bool operator<(const TIME::Evt& e1, const TIME::Evt& e2); // � d�finir !!!!

#endif