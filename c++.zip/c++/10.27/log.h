#if !defined(LOG_H)
#define LOG_H
#include "timing.h"
#include<iostream>
#include <exception>
#include "evenement.h"
using namespace TIME;


// Interface objectif : l'interface que l'on veut impl�menter
class Log { // classe abstraite
public:
	// il y a deux constructeurs par d�faut : celui sans argument, celui par recopie
	// il y a aussi un destructeur par default
	virtual ~Log() = default; // il faut un destructeur virtuel pour respecter le principe de substitution
	virtual void addEvt(const TIME::Date& d, const TIME::Horaire& h, const std::string& s) = 0;
	virtual void displayLog(std::ostream& f) const = 0;
};

class LogException : public std::exception {
private:
	string info;
public:
	LogException(const string& i):info(i){}
	const char* what() const noexcept {
		return info.c_str();
	}
};

// classe adaptatrice : classe avec la bonne interface (celle de Log) et qui utilise le comportement de la classe Agenda
class MyLog : public Log, private Agenda { // ici, on utilise l'adapteur de classe

public:
	MyLog() = default;
	~MyLog() = default;
	
	void addEvt(const TIME::Date& d, const TIME::Horaire& h, const std::string& s) {
		Evt1jDur e(d, s, h, Duree(0));

		if (begin() != end()) {
			// agenda non vide
			auto it = end();
			--it; // on se place sur le dernier evt
			const Evt& dernier = *it;
			if (e < dernier) throw LogException("corruption du log  avec un evt anterieur");
		}
		//Agenda::operator<<(e);
		//this->operator<<(e);
		*this << e;
	}
	
	void displayLog(std::ostream& f) const {
		for (auto it = begin(); it != end(); ++it) {
			try {
				const Evt1jDur& e = dynamic_cast<const Evt1jDur&>(*it); // il faut faire une convertion Evt& -> Evt1jDur&
																		// pour acc�der � la date et � l'horaire de l'Evt
				f << e.getDate() << " - " << e.getHoraire() << " : " << e.getDescription() << "\n";

			}catch(...){}
		}
	}
};

// classe adaptatrice : classe avec la bonne interface (celle de Log) et qui utilise le comportement de la classe Agenda
class MyLog2 : public Log { 
private:
	Agenda A; // objet adapt� => ici, on utilise l'adapteur d'objet  

public:
	MyLog2() = default;
	~MyLog2() = default;

	void addEvt(const TIME::Date& d, const TIME::Horaire& h, const std::string& s) {
		Evt1jDur e(d, s, h, Duree(0));
	
		if (A.begin() != A.end()) {
			// agenda non vide
			auto it = A.end();
			--it; // on se place sur le dernier evt
			const Evt& dernier = *it;
			if (e < dernier) throw LogException("corruption du log  avec un evt anterieur");
		}
		
		A << e; // on ajoute l'evt dans l'agenda 
	}

	void displayLog(std::ostream& f) const {
		for (auto it = A.begin(); it != A.end(); ++it) {
			try {
			    //*it renvoie une valeur de type Evt&
			    //mais on a besoin d'un Evt1jDur& pour utiliser getDate() et getHoraire()
				const Evt1jDur& e = dynamic_cast<const Evt1jDur&>(*it); // il faut faire une convertion Evt& -> Evt1jDur&
																		// pour acc�der � la date et � l'horaire de l'Evt
				f << e.getDate() << " - " << e.getHoraire() << " : " << e.getDescription() << "\n";

			}
			catch (...) {}
		}
	}
};






#endif