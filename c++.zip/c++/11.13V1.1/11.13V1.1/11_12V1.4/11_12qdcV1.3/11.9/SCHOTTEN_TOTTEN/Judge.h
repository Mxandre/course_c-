//
// Created by xiangyang on 2023/10/25.
//
#include"Carte.h"
#include"Chateau.h"
#include<iostream>
#ifndef SCHOTTEN_TOTTEN_JUDGE_H
#define SCHOTTEN_TOTTEN_JUDGE_H

#endif //SCHOTTEN_TOTTEN_JUDGE_H
