//
// Created by xiangyang on 2023/10/25.
//

#ifndef SCHOTTEN_TOTTEN_PLAYER_H
#define SCHOTTEN_TOTTEN_PLAYER_H

#include"Chateau.h"
#include<iostream>

using namespace Carte_name;



#endif //SCHOTTEN_TOTTEN_PLAYER_H
