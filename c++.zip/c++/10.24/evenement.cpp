#include "evenement.h"

ostream& operator<<(ostream& f, const TIME::Evt& e) {
	e.afficher(f);
	return f;
}

