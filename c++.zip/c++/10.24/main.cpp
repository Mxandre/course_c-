#include "graph.h"
#include <iostream>
#include <typeinfo>
#include <sstream>
#include "evenement.h"
#include "log.h"
using namespace std;
using namespace TIME;



int main() {
	int x;
	int* pt = &x;
	int& ref = *pt;



	Evt1j e1(Date(4, 10, 1957), "Spoutnik");
	Evt1j e2(Date(11, 6, 2013), "Shenzhou");
	Evt1jDur e3(Date(11, 6, 2013), "Lancement de Longue Marche", Horaire(17, 38), Duree(0, 10));
	Rdv e4(Date(11, 4, 2013), "reunion UV", Horaire(17, 30), Duree(60), "Intervenants UV", "		bureau");
	Agenda A;
	A << e2;
	A << e1 << e3 << e4;
	A.afficher();

	cout << "=====================\n";
	for (auto it = A.begin(); it != A.end(); ++it)
		cout << *it;
	cout << "=====================\n";
	for (auto& e : A)
		cout << e;

	return 0;
}

