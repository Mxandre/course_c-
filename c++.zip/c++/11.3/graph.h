#include<map>
#include<set>
#include<string>
#include<iostream>

using namespace std;
template<class Vertex> // Vertex repr�sente le type de sommets dans un graphe
class GraphG {
	// une map associe des cl�s � des valeurs
	// pour chaque sommet Vertex du graphe, on associe un set<Vertex>, c'est � dire un ensemble de sommets successeurs
	map<Vertex, set<Vertex> > adj;
	string name;
public:
	GraphG(const string& n) :name(n) {} // adj est initialis� par d�faut : au d�but, il est vide : utilise son constructeur sans argument
	const string& getName() const { return name; }
	size_t getNbVertices() const { return adj.size(); } // il y autant de sommets, qu'il y a de cl�s dans le map (une cl� = un sommet)
	size_t getNbEdges() const;
	void addVertex(const Vertex& i);
	void addEdge(const Vertex& i, const Vertex& j);
	void removeEdge(const Vertex& i, const Vertex& j);
	void removeVertex(const Vertex& i);
	void print(ostream& f) const;
	
	// un vertex_iterator est comme un map<Vertex, set<Vertex>>::iterator
	// mais * doit renvoyer un Vertex au lieu d'un pair<Vertex,set<Vertex>>
	class vertex_iterator : public map<Vertex, set<Vertex>>::iterator {
	public:
		vertex_iterator(typename map<Vertex, set<Vertex>>::iterator it) :map<Vertex, set<Vertex>>::iterator(it) {}
		const Vertex& operator*() { return map<Vertex, set<Vertex>>::iterator::operator*().first; }
	};
	vertex_iterator begin_vertex() { return vertex_iterator(adj.begin()); }
	vertex_iterator end_vertex() { return vertex_iterator(adj.end()); }

	// quand on utilise un successor_iterator sur le sommet i, c'est pour parcourir le set<Vertex> associ� � i dans la map
	// un successor_iterator est donc un set<Vertex>::iterator
	using successor_iterator = typename set<Vertex>::iterator;
	successor_iterator begin_successor(const Vertex& i) { return adj[i].begin(); }
	successor_iterator end_successor(const Vertex& i) { return adj[i].end(); }
};

template<class Vertex> void GraphG<Vertex>::addVertex(const Vertex& i) {
	// d�clenche une exception si le sommet i existe d�j�
	//if (adj.find(i) != adj.end()) throw "sommet deja existant";
	if (adj.count(i) != 0) throw "sommet deja existant";
	// sinon ajouter le sommet i dans la map
	//adj.insert(pair < Vertex, set<Vertex>(i, set<Vertex>())); // on associe un ensemble vide (pas de sucesseurs) au sommet i que l'on ajoute
	//adj.insert(make_pair(i, set<Vertex>()));
	//adj[i] = set<Vertex>(); // cr�e la cl� i dans le map et lui associe l'ensemble vide
	adj[i]; // cr�e la cl� i dans le map et lui associe la valeur par d�faut set<Vertex>() = l'ensemble vide
}

template<class Vertex> void GraphG<Vertex>::addEdge(const Vertex& i, const Vertex& j) {
	// ajoute l'arc (i,j) s'il n'existe pas sinon d�clence une exception
	// si le sommet i ou j n'existe pas encore, on cr�e le sommet en m�me temps que l'arc
	auto it = adj[i].find(j);// comme on a fait ajd[i], cela a cr�� i s'il n'existe pas encore
	if (it != adj[i].end()) throw "arc deja existant"; 
	adj[j]; // cr�e le sommet j si besoin
	adj[i].insert(j); // on ajoute (i,j)
}


template<class Vertex> void GraphG<Vertex>::removeEdge(const Vertex& i, const Vertex& j) {
	// d�clenche une exception si l'arc (i,j) n'existe pas sinon retire l'arc (i,j) => retire j des successeurs de i
	auto iti = adj.find(i);
	if (iti == adj.end()) throw "sommet inexistant";
	auto itj = iti->second.find(j);
	if (itj == iti->second.end()) throw "arc inexistant";
	iti->second.erase(itj); // ajd[i].erase(j);
}

template<class Vertex> void GraphG<Vertex>::removeVertex(const Vertex& i) {
	// doit enlever le sommet i, l'ensemble des arcs (i,j) et l'ensemble des arcs (j,i)
	// d�clenche une exception si i n'existe pas
	auto iti = adj.find(i);
	if (iti == adj.end()) throw "sommet inexistant";
	adj.erase(iti); // retire i et son ensemble de succeseurs, c'est � dire tous les arcs (i,j)
	// il faut retirer tous les arcs (j;i)
	for (auto& c : adj) c.second.erase(i); // on retire i de tous les ensembles de successeurs
}


template<class Vertex> void GraphG<Vertex>::print(ostream& f) const {
	f << "Graph " << name << "\n";
	for (auto& c : adj) {
		f << c.first << " : "; // on affiche un sommet
		for (auto& s : c.second) f << s << ";"; // on affiche tous ses successeurs
		f << "\n";
	}
}

template<class V> ostream& operator<<(ostream& f, const GraphG<V>& G) {
	G.print(f);
	return f;
}

template<class Vertex> size_t GraphG<Vertex>::getNbEdges() const {
	// pour calculer le nombre, il faut faire la somme de la taille de chaque ensemble de successeurs des sommets
	size_t nb = 0; // nb d'arcs
	for (auto it = adj.begin(); it != adj.end(); ++it) nb += it->second.size();
	return nb;
}