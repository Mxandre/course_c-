#if !defined(_Container_T_H)
#define _Container_T_H
#include<string>
#include<stdexcept>
namespace TD {
	class ContainerException : public std::exception {
	protected:
		std::string info;
	public:
		ContainerException(const std::string& i = "") noexcept :info(i) {}
		const char* what() const noexcept { return info.c_str(); }
		~ContainerException()noexcept {}
	};

	template<class T> // T est le type des objets contenus dans le Container
	class Container {
	protected: // partie accessible � la classe fille
		size_t nb=0;
	public:
		// on doit d�cider quelles sont les m�thodes :
		// - concr�tes : m�thodes que l'on impl�mente dans Container et qui ne pourront pas �tre red�finies dans les classes filles
		// - virtuelles : m�thodes que l'on impl�mente dans Container et qui pourront �tre red�finies dans les classes filles
		// - virtuelles pures : m�thodes que l'on sait pas impl�menter dans Container : elles devront �tre d�finies dans les classes filles

		// m�thodes concr�tes qui n'ont pas besoin d'�tre red�finies dans les classes filles
		size_t size() const { return nb;  } //qui renvoie la taille du conteneur.
		bool empty() const { return nb == 0; } //qui renvoie vrai si le conteneur est vide et faux sinon.

		// m�thodes virtuelles pures : on ne sait pas d�finir ces m�thodes dans Container car elle d�pendent des classes filles
		virtual T& element(size_t i)=0; //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		virtual const T & element(size_t i)const=0; //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		virtual void push_back(const T& x)=0; //qui ajoute un objet x au conteneur apr�s le dernier objet.
		virtual void pop_back()=0; //qui retire le dernier objet du conteneur.

		// template m�thods : elles utilisent des m�thodes virtuelles pures sur les parties que l'on ne sait pas faire
		T& front() { return element(0); } //qui renvoie une r�f�rence const sur le premier objet contenu dans le conteneur.
		const T& front()const { return element(0); } //qui renvoie une r�f�rence const sur le premier objet contenu dans le conteneur.
		T& back() { return element(nb-1); } //qui renvoie une r�f�rence sur le dernier objet contenu dans le conteneur.
		const T& back()const { return element(nb - 1); } //qui renvoie une r�f�rence const sur le dernier objet contenu dans le conteneur.
		
		// cette m�thode est virtuelle : on autorise la red�finition dans les classes filles
		virtual void clear() { while (!empty()) pop_back(); } //qui retire tous les objets du conteneur.
	
		// constructeurs / destructeurs
		Container(size_t n):nb(n){}
		virtual ~Container() = default; // il faut un destructeur virtuel pour respecter le principe de substitution :
										// la classe Container va avoir des classes filles
	};


	template<class T>
	class Vector : public Container<T> { // type sp�cial de Container<T>
	private:
		T* tab; // tableau allou� dynamiquement
		size_t nbMax; //repr�sente la taille du tableau allou� dynamiquement
	public:

		Vector(size_t n=0, const T& init=T()) : Container<T>(n), tab(new T[n]), nbMax(n) { for (size_t i = 0; i < n; i++) tab[i] = init; }
		~Vector() { delete[] tab; } // on doit d�truire le tableau allou� dynamiquement
		
		size_t capacity() const { return nbMax; } // renvoie la taille du tableau allou� dynamiquement = la capacit�
		void reserve(size_t n); // augmente la capacit� jusqu'� n si n>nbMax (sinon ne fait rien)
		
		T& operator[](size_t i) { return tab[i]; } //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		const T& operator[](size_t i) const { return tab[i]; } //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		// impl�mentation des m�thodes virtuelles pures de Container
		T& element(size_t i); //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		const T& element(size_t i) const; //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		void push_back(const T& x); //qui ajoute un objet x au conteneur apr�s le dernier objet.
		void pop_back(); //qui retire le dernier objet du conteneur.
		Vector(const Vector<T>& v);
		Vector<T>& operator=(const Vector<T>& v);

		// on red�finit clear() car on sait faire la m�thode plus efficacement
		// on a le droit car clear() est virtual
		void clear() { this->nb = 0; }
	};

	template<class T> void Vector<T>::push_back(const T& x) { //qui ajoute un objet x au conteneur apr�s le dernier objet.
		reserve(this->nb + 1);
		tab[this->nb++] = x;
	}

	template<class T> void Vector<T>::pop_back() { //qui retire le dernier objet du conteneur.
		this->nb--;
	}
	
	template<class T> Vector<T>::Vector(const Vector<T>& v):Container<T>(v.size()),tab(new T[v.size()]),nbMax(v.size()) {
		for (size_t i = 0; i < v.size(); i++) tab[i] = v.tab[i]; // on recopie tous les �l�ments du Vector v
	}
	
	template<class T> Vector<T>& Vector<T>::operator=(const Vector<T>& v) {
		if (this != &v) { // on v�rifie l'auto-affectation
			reserve(v.size());
			for (size_t i = 0; i < v.size(); i++) tab[i] = v.tab[i]; // on recopie tous les �l�ments du Vector v
			this->nb = v.size();
		}
		return *this;
	}

	template<class T> T& Vector<T>::element(size_t i) { //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		if (i >= Container<T>::nb) throw ContainerException("out of range");
		return tab[i];
	}

	template<class T> const T& Vector<T>::element(size_t i) const { //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		if (i >= Container<T>::nb) throw ContainerException("out of range");
		return tab[i];
	}

	// pour d�finir une m�thode d'une classe patron � l'ext�rieur de la classe, il faut :
	// 1- red�clarer les param�tres avec template
	// 2- param�trer l'op�rateur de r�solution de port�e
	// 3- mettre la d�finition dans le .h (pas dans le .cpp) si on veut utiliser le patron dans plusieurs fichiers sources
	template<class T> void Vector<T>::reserve(size_t n) {
		if (n > nbMax) { // on agrandit le tableau si n>nbMax
			auto newtab = new T[n]; // on cr�e un nouveau tableau
			// attention, pour acc�der � un membre de Container<T>, comme nb, il faut utiliser this-> ou Container<T>::
			for (size_t i = 0; i < this->nb; i++) newtab[i] = tab[i]; // on recopie les �l�ments du tableau initial
			auto old = tab;
			tab = newtab; nbMax = n; // on met � jour les attributs
			delete[] old; // on d�truit l'ancien tableau
		}
	}

	void reserve(size_t n); // augmente la capacit� jusqu'� n si n>nbMax (sinon ne fait rien)



	template<class T>
	class Liste : public Container<T> { // type sp�cial de Container<T>
	private:
		class Cellule {

		}; // cellules de la liste chain�e
	};

	// adaptateur de classe
	namespace AC {
		// CONT est une strat�gie : on laisse l'utilisateur choisir la classe � adapter
		template<class T, class CONT=Vector<T>> class Stack : private CONT { // utilise l'h�ritage priv� pour r�utiliser le comportement d'un Container
		public:
			Stack() = default;
			~Stack() = default;
			bool empty() const { return CONT::empty(); }
			void push(const T& x) { return this->push_back(x); } // qui empile un objet dans la pile.
			void pop() { this->pop_back(); } // qui d�pile le dernier �l�ment empil� de la pile.
			size_t size() const { return CONT::size(); }
			T& top() { return CONT::back(); } //qui renvoie une r�f�rence sur le dernier objet empil� de la pile
			const T& top() const { return CONT::back(); }
			void clear() { CONT::clear(); }
		};
	}
	// adaptateur d'objet
	namespace AO { 
		// CONT est une strat�gie : on laisse l'utilisateur choisir la classe � adapter
		template<class T, class CONT = Vector<T>> class Stack { 
		private:
			CONT cont; // utilise un objet avec la composition pour r�utiliser le comportement d'un Container
		public:
			Stack() = default;
			~Stack() = default;
			bool empty() const { return cont.empty(); }
			void push(const T& x) { return cont.push_back(x); } // qui empile un objet dans la pile.
			void pop() { cont.pop_back(); } // qui d�pile le dernier �l�ment empil� de la pile.
			size_t size() const { return cont.size(); }
			T& top() { return cont.back(); } //qui renvoie une r�f�rence sur le dernier objet empil� de la pile
			const T& top() const { return cont.back(); }
			void clear() { cont.clear(); }
		};

	}


}
#endif