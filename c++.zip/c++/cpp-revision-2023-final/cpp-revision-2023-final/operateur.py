__author__ = "lunde chen"
__email__  = "lundechen@shu.edu.cn"

from litterale import *

class Operateur(Litterale):
    def __init__(self):
        Litterale.__init__(self)
        self.type = 'Operateur'
        self.symbol = ''

    def calculate(self):
        return Litterale()##占位符

    def print_with_result(self):
        print(self.__str__(), "=", self.calculate().__str__())


class OperateurOneArgument(Operateur):
    def __init__(self, x):
        Operateur.__init__(self)
        self.x_str = x.__str__()
        self.x = x.calculate()

    def __str__(self):
        return '(' + self.symbol + self.x_str + ')'


class OperateurNeg(OperateurOneArgument):
    def __init__(self, x):
        OperateurOneArgument.__init__(self, x)
        self.symbol = '-'

    def calculate(self):
        result = Litterale()
        if self.x.level == 3:##实数
            result = LitteraleReelle(-1 * self.x.value)
        elif self.x.level == 2:##分数
            result = LitteraleRationnelle(-1 * self.x.fz, self.x.fm)
        elif self.x.level == 1:##整数
            result = LitteraleEntier(-1 * self.x.value)
        return result


class OperateurTwoArguments(Operateur):
    def __init__(self, x, y):
        Operateur.__init__(self)
        self.x_str = x.__str__()
        self.y_str = y.__str__()
        self.x = x.calculate()
        self.y = y.calculate()

    def __str__(self):
        return '(' + self.x_str + self.symbol + self.y_str + ')'


class OperateurPlus(OperateurTwoArguments):
    def __init__(self, x, y):
        OperateurTwoArguments.__init__(self, x, y)
        self.symbol = '+'

    def calculate(self):
        result = Litterale()
        if max(self.x.level, self.y.level) == 3:##当中有实数
            result = LitteraleReelle(float(self.x.value + self.y.value))
        if max(self.x.level, self.y.level) <= 2:##分数或整数
            _fz = self.x.fz * self.y.fm + self.y.fz * self.x.fm
            _fm = self.x.fm * self.y.fm
            result = LitteraleRationnelle(_fz, _fm)
            result = result.simplify()
        return result


class OperateurMinus(OperateurTwoArguments):
    def __init__(self, x, y):
        OperateurTwoArguments.__init__(self, x, y)
        self.symbol = '-'

    def calculate(self):
        result = Litterale()
        if max(self.x.level, self.y.level) == 3:
            result = LitteraleReelle(float(self.x.value - self.y.value))
        if max(self.x.level, self.y.level) <= 2:
            _fz = self.x.fz * self.y.fm - self.y.fz * self.x.fm
            _fm = self.x.fm * self.y.fm
            result = LitteraleRationnelle(_fz, _fm)
            result = result.simplify()
        return result


class OperateurTimes(OperateurTwoArguments):
    def __init__(self, x, y):
        OperateurTwoArguments.__init__(self, x, y)
        self.symbol = '*'

    def calculate(self):
        result = Litterale()
        if max(self.x.level, self.y.level) == 3:
            result = LitteraleReelle(float(self.x.value * self.y.value))
        if max(self.x.level, self.y.level) <= 2:
            _fz = self.x.fz * self.y.fz
            _fm = self.x.fm * self.y.fm
            result = LitteraleRationnelle(_fz, _fm)
            result = result.simplify()
        return result


class OperateurDivision(OperateurTwoArguments):
    def __init__(self, x, y):
        OperateurTwoArguments.__init__(self, x, y)
        self.symbol = '/'

    def calculate(self):
        result = Litterale()
        if max(self.x.level, self.y.level) == 3:
            result = LitteraleReelle(float(self.x.value / self.y.value))
        if max(self.x.level, self.y.level) <= 2:
            _fz = self.x.fz * self.y.fm
            _fm = self.x.fm * self.y.fz
            result = LitteraleRationnelle(_fz, _fm)
            result = result.simplify()
        return result

