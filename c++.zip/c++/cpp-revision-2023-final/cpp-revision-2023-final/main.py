__author__ = "lunde chen"
__email__  = "lundechen@shu.edu.cn"

from litterale import *
from operateur import *

if __name__ == "__main__":
    a = LitteraleEntier(10)
    print(a)
    b = LitteraleEntier(20)
    print(b)
    c = OperateurPlus(a, b)
    print(c)
    c.print_with_result()
    d = OperateurPlus(a, b)
    print(d)
    d.print_with_result()
    e = OperateurPlus(c, d)
    print(e)
    e.print_with_result()
    f = OperateurNeg(a)
    print(f)
    f.print_with_result()
    g = LitteraleRationnelle(9, 10)
    print(g)
    h = OperateurNeg(g)
    print(h)
    h.print_with_result()
    i = OperateurPlus(g, a)
    print(i)
    i.print_with_result()
    j = OperateurPlus(h, a)
    print(j)
    j.print_with_result()
