__author__ = "lunde chen"
__email__  = "lundechen@shu.edu.cn"


class Litterale:
    def __init__(self):
        self.type = 'LitteraleBase'
        self.value = 0
        self.level = 10

    def __str__(self):
        return str(self.value)##将字符与设定的整数值进行连接，若是0，则得到“0”

    def calculate(self):
        return self


class LitteraleEntier(Litterale):
    def __init__(self, _input):
        Litterale.__init__(self)
        self.type = 'Entier'##整数类型
        self.value = int(_input)
        self.fz = int(_input)##分子
        self.fm = 1##分母
        self.level = 1

    def __str__(self):
        return str(int(self.value))##返回整数


class LitteraleRationnelle(Litterale):
    def __init__(self, fz, fm):
        Litterale.__init__(self)
        self.type = 'Rationnelle'
        self.fz = fz
        self.fm = fm
        self.value = float(self.fz) / float(self.fm)
        self.level = 2

    def __str__(self):
        self.simplify()
        if self.fm == 1:
            return LitteraleEntier(self.fz).__str__()##如果分母为0
        return str(self.fz) + '/' + str(self.fm)##返回字符串形式

    def simplify(self):
        import math
        gcd = math.gcd(self.fz, self.fm)
        self.fz = int(self.fz / gcd)
        self.fm = int(self.fm / gcd)
        if self.fm == 1:
            return LitteraleEntier(self.fz)
        return self


class LitteraleReelle(Litterale):
    def __init__(self, _input):
        Litterale.__init__(self, _input)
        self.type = 'Reelle'
        self.value = float(_input)
        self.level = 3##实数
