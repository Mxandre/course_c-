#if !defined(_Container_T_H)
#define _Container_T_H
#include<string>
#include<stdexcept>
namespace TD {
	class ContainerException : public std::exception {
	protected:
		std::string info;
	public:
		ContainerException(const std::string& i = "") noexcept :info(i) {}
		const char* what() const noexcept { return info.c_str(); }
		~ContainerException()noexcept {}
	};

	template<class T> // T est un param�tre de type : un type que l'on ne connait pas encore
	class Container {
		// pour chaque m�thode, on doit d�cider si elle est :
		// - concr�te non virtuelle : on la d�finit dans Container, elle ne doit pas �tre red�finie dans les classes filles
		// - concr�te virtuelle : on la d�finit dans Container : on peut red�finir le comportement dans les classes filles
		// - virtuelle pure : on ne sait pas la d�finir dans Container : on doit d�finir le comportement dans les classes filles
	protected : // partie accessible aux m�thodes des classes d�riv�es
		size_t nb; // nb d'�l�ments dans le container
	public:	
		size_t size() const { return nb; } //qui renvoie la taille du conteneur.
		bool empty() const { return nb == 0; } //qui renvoie vrai si le conteneur est vide et faux sinon.
		
		// les m�thodes suivantes sont virtuelles pures car leur impl�mentation d�pend des classes filles
		virtual T& element(size_t i) = 0; //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		virtual const T & element(size_t i)const=0; //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		virtual void push_back(const T& x) = 0; //qui ajoute un objet x au conteneur apr�s le dernier objet.
		virtual void pop_back() = 0; //qui retire le dernier objet du conteneur.

		// les m�thodes suivantes sont des template methods
		T& front() { return element(0); } //qui renvoie une r�f�rence const sur le premier objet contenu dans le conteneur.
		const T& front() const { return element(0); } //qui renvoie une r�f�rence const sur le premier objet contenu dans le conteneur.
		T& back() { return element(nb-1); } //qui renvoie une r�f�rence sur le dernier objet contenu dans le conteneur.
		const T& back()const { return element(nb - 1); } //qui renvoie une r�f�rence const sur le dernier objet contenu dans le conteneur.
		virtual void clear() {	while (!empty()) pop_back(); }//qui retire tous les objets du conteneur.
	
		virtual ~Container() = default; // il faut un destructeur virtual car Container va avoir des classes filles
	};

	template<class T>
	class Vector : public Container<T> {
	private:
		T* tab; // tableau allou� dynamiquement
		size_t nbMax; // la taille du tableau allou�
	public:
		Vector(size_t n, const T& init);
		~Vector();
		Vector(const Vector<T>& v);
		Vector& operator=(const Vector<T>& v);
		T& operator[](size_t i) = 0; //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		const T& operator[](size_t i)const = 0; //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		T& element(size_t i) = 0; //qui renvoie une r�f�rence sur le ie �l�ment d'un conteneur.
		const T& element(size_t i)const = 0; //qui renvoie une r�f�rence const le ie �l�ment d'un conteneur.
		void push_back(const T& x) = 0; //qui ajoute un objet x au conteneur apr�s le dernier objet.
		void pop_back() = 0; //qui retire le dernier objet du conteneur.
	};


}
#endif