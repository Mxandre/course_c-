#include<map>
#include<set>
#include<string>
#include<iostream>

using namespace std;
template<class Vertex> // Vertex repr�sente le type de sommets dans un graphe
class GraphG {
	// une map associe des cl�s � des valeurs
	// pour chaque sommet Vertex du graphe, on associe un set<Vertex>, c'est � dire un ensemble de sommets successeurs
	map<Vertex, set<Vertex> > adj;
	string name;
public:
	GraphG(const string& n) :name(n) {} // adj est initialis� par d�faut : au d�but, il est vide : utilise son constructeur sans argument
	const string& getName() const { return name; }
	size_t getNbVertices() const { return adj.size(); } // il y autant de sommets, qu'il y a de cl�s dans le map (une cl� = un sommet)
	size_t getNbEdges() const;
	void addVertex(const Vertex& i);
	void addEdge(const Vertex& i, const Vertex& j);
	void removeEdge(const Vertex& i, const Vertex& j);
	void removeVertex(const Vertex& i);
	void print(ostream& f) const;
};
template<class V> ostream& operator<<(ostream& f, const GraphG<V>& G);

template<class Vertex> size_t GraphG<Vertex>::getNbEdges() const {
	// pour calculer le nombre, il faut faire la somme de la taille de chaque ensemble de successeurs des sommets
	size_t nb = 0; // nb d'arcs
	for (auto it = adj.begin(); it != adj.end(); ++it) nb += it->second.size();
	return nb;
}