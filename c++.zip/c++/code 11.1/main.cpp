#include "container.h"
#include <iostream>
#include <list>
#include <set>
#include <map>
#include <string>
bool plus_grand_fx(int a, int b) { return a > b; }

struct plus_grand_obj {
	bool operator()(int a, int b) const { return a > b; }
};

void exemple() {
	using namespace std;

	set<int> notes1;
	notes1.insert(99); notes1.insert(86); notes1.insert(75);

	set<int> notes2;
	notes2.insert(70); notes2.insert(80); notes2.insert(90);

	map<string, set<int>> etudiants;
	etudiants["Leopold"] = notes1;
	etudiants["Julie"] = notes2;

	for (auto it = etudiants.begin(); it != etudiants.end(); ++it) {
		// une map est un ensemble de couples de type pair<key,value>, ici pair<string, set<int>>
		// quand on fait *it, on obtient un objet pair<string, set<int>>
		// l'attribut first de cet objet est la string (ici l'�tudiant)
		// l'attribut seconde de cet objet est le set<int> (ici, l'ensemble de notes)
		//std::cout << "notes de " << (*it).first << "=";
		std::cout << "notes de " << it->first << "=";
		for (auto itn = it->second.begin(); itn != it->second.end(); ++itn) std::cout << *itn << ";";
		std::cout << "\n";
	}

}


int main() {
	using namespace TD;
	using namespace std;
	Vector<int> v(5, 0);
	v.push_back(42);
	v.push_back(36);
	v.push_back(8);
	v.pop_back();
	v.reserve(20);
	std::cout << "size=" << v.size() << "\n"<< v[3] << "\n";
	v.clear();
	for (auto it = v.begin(); it != v.end(); ++it) std::cout << *it << "\n";
	for (auto& e : v) std::cout << e << "\n";
	auto itmin = minimum_element(v.begin(), v.end()); // obtenir un it�rateur sur l'�l�ment minimum (par rapport � operator<) de v

	auto itmax= minimum_element(v.begin(), v.end(),plus_grand_fx); // pointeur de fonction
	plus_grand_obj comp;
	itmax = minimum_element(v.begin(), v.end(), comp); // objet fonction
	itmax = minimum_element(v.begin(), v.end(), plus_grand_obj()); // objet fonction
	auto lexp = [](int a, int b) { return a > b; };
	itmax = minimum_element(v.begin(), v.end(), lexp); // lambda-expression
	itmax = minimum_element(v.begin(), v.end(), [](int a, int b) { return a > b; }); // lambda-expression


	set<int> ens;
	ens.insert(-6);
	ens.insert(18);
	ens.insert(-14);
	ens.insert(42);
	auto itmin2 = minimum_element(ens.begin(), ens.end()); // obtenir un it�rateur sur l'�l�ment minimum (par rapport � operator<) de ens



	AC::Stack<int> s; // utilise Vector<int>
	s.push(42);
	s.push(36);
	s.pop();
	s.push(10);
	std::cout << "size=" << s.size() << "\n";
	s.clear();
	
	AC::Stack<int, std::list<int> > s2; // utilise std::list<int>
	s2.push(42);
	s2.push(36);
	s2.pop();
	s2.push(10);
	std::cout << "size=" << s2.size() << "\n";
	s2.clear();

	AO::Stack<int, std::list<int> > s3; // utilise std::list<int>
	s3.push(42);
	s3.push(36);
	s3.pop();
	s3.push(10);
	std::cout << "size=" << s3.size() << "\n";
	s3.clear();

	
	return 0;
}
